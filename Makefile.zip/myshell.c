#include "myshell.h"
#include <stdio.h>




#define ArgSize 64
#define bufSize 1024
#define fileLength 256

#define fformat " \t\n"

#define MAX_ARGS 20

int arguments;
extern char **env;
char inputLine[bufSize];
char shellPath[bufSize];
char path[bufSize];
char shellPath2[bufSize];
char * args[ArgSize];
char ** tokenArg;
char readFiles[3][fileLength];
char LCheck[3];
char *Opertors[4]={">>",">" ,"<"};


int Tokenizer(char* shellinput, char* args[]) 
{
  int i = 0;

  if((args[0] = strtok(shellinput, "\n\t ")) == NULL) {
    return 0; 
}
  while((args[++i] = strtok(NULL, "\n\t ")) != NULL) 
  {
    if(i >= MAX_ARGS) {
      printf("Too many arguments!\n");
      exit(1);
    }
  }
  return i;
}

void parse(char* shellinput) 
{
  int pid, async;
  char* args[MAX_ARGS];

  int nargs = Tokenizer(shellinput, args);
  if(nargs <= 0) return;

  if(!strcmp(args[0], "quit") || !strcmp(args[0], "exit") || !strcmp(args[0], "EXIT")|| !strcmp(args[0], "QUIT")) {
    exit(0);
  }

  if(!strcmp(args[nargs-1], "&")) { async = 1; args[--nargs] = 0; }
  else async = 0;

  pid = fork();
  if(pid == 0) {
    execvp(args[0], args);
    perror("EXEC ERROR");
    exit(-1);
  } else if(pid > 0) 
  {
    if(!async) waitpid(pid, NULL, 0);
    else printf("ASYNCHRONOUS CALL\n");
  } else {
    perror("FORK ERROR");
    exit(1);
  }
}

int TokCheck(char *str)
{
  char c;
  for (int i=0;i<strlen(str);i+=1)
  {
    c=str[i];
    if (c=='|'){
      return 1;
    }
  }
  return 0;
}

int main (int argc, char* argv [])
{

  signal(SIGINT, SIG_IGN);
  getcwd(shellPath,bufSize-1);
  strcpy(shellPath2,shellPath);
  strcat(shellPath2,"/myshell");
  setenv("SHELL",shellPath2, 1);

  if (argc>2){
    error("Maximum one argument is allowed: a batch file name\n");
  }
  else if (argc==2)
  {
    readBatchFile(argv[1]);
  }

  while (!feof(stdin))
  {
    updatePath();
    //prompting output
    printf("project-1$ ");
    
    if (fgets(inputLine,bufSize,stdin)){
      if (TokCheck(inputLine)==1){
          system(inputLine);    
      }
      else{
      tokenize();

      int backRun=0;
      if (arguments>1 && !strcmp(args[arguments-1],"&")){
        args[arguments-1]=(char*)0;
        backRun=1;
      }
    
      if (backRun){
        switch (fork()){
          case -1:
            error("fork error");
            break;
          case 0:
            setenv("PARENT",shellPath2,1);
            runCommand();
            exit(0);
            break;
        }
      }
      else {
        
        runCommand();
        
      }
      }
    }
}
  
  //Part1 code
 /* char shellinput[BUFSIZ];
  
  for(;;) {
    printf("project-1$ ");
    if(fgets(shellinput, BUFSIZ, stdin) == NULL) {
      perror("fgets failed");
      exit(1);
    }
    parse(shellinput) ;
  }*/
  return 0;
}

//print method

void error(char msg[bufSize]){
  printf("%s. \n",msg);
  exit(1);
}

//Update method

void updatePath() {
  getcwd(path,bufSize-1);
}

void tokenize(){
  
  char *tmp,*pt;
  int i;
  for (i=0;i<3;i+=1){
    LCheck[i]=0;
    if ((pt=strstr(inputLine,Opertors[i]))!=NULL){
      tmp=strtok(pt + strlen(Opertors[i]),fformat);
      strcpy(readFiles[i],tmp);
      LCheck[i]=1;
      *pt='\0';
       if ((tmp=strtok(NULL,fformat))!= NULL)
         { strcat(inputLine,tmp);}
      
    }
    
  }
  
  arguments=1;
  tokenArg=args;
  
  *tokenArg++ = strtok(inputLine,fformat);
  
  while ((*tokenArg++=strtok(NULL,fformat))){
    arguments++;
  }
}

//signal method
void sigChild(){
  signal(SIGINT,SIG_IGN);
  putchar('\n');
}

//defination  Output redirection
void ioRedirect(int readAllowed){
  
  if (LCheck[0]==1){
    freopen(readFiles[0],"a",stdout);
  }
  if (LCheck[1]==1){
    freopen(readFiles[1],"w",stdout);
  }
  if (LCheck[2]==1 && readAllowed == 1){
    freopen(readFiles[2],"r",stdin);
  }
}

//defination Restore Output redirection

void ioRedirectClose(){
  if (LCheck[0] || LCheck[1]){
    freopen("/dev/tty","w",stdout);
  }
}

//runCommand
void runCommand(){
  
  if (args[0]){
     
    if (!strcmp(args[0],"clr")){
      system("clear");
    }
    else if (!strcmp(args[0],"ls")){
      ioRedirect(0);
      
      char tmp[bufSize];
      strcpy(tmp,"ls");
      if (args[1]){
        strcat(tmp,args[1]);
      }
      system(tmp);
      ioRedirectClose();
    }
    else if (!strcmp(args[0],"dir")){
      
      ioRedirect(0);
      
      char tmp[bufSize];
      strcpy(tmp,"ls -la ");
      if (args[1]){
        strcat(tmp,args[1]);
      }
      system(tmp);
      ioRedirectClose();
    }
    else if (!strcmp(args[0],"env")){
      ioRedirect(0);
      char **env=env;
      while (*env){
        printf("%s\n",*env);
        env++;
      }
      ioRedirectClose();
    }
    else if (!strcmp(args[0],"echo")){
      ioRedirectClose(0);

      char *comment=(char *)malloc(bufSize);
      strcpy(comment,"");
      tokenArg=&args[1];
      while (*tokenArg){
        strcat(comment,*tokenArg++);
        strcat(comment," ");
      }
      printf("%s\n",comment);
      memset(comment,0,bufSize);
      free(comment);

      ioRedirectClose();
    }

    //print how to use
    else if (!strcmp(args[0],"help")){

      ioRedirect(1);
      char tmp[bufSize];
      strcpy(tmp, "more ");
      strcat(tmp, shellPath);
      strcat(tmp,"/readme");
      system(tmp);
      putchar('\n');

      ioRedirectClose();
    }
    else if (!strcmp(args[0],"pause")){
      getpass("press Enter to Continue\n");
    }

    else if (!strcmp(args[0],"quit")){
      
      exit(0);
    }

    else {
       
      int status;
      pid_t pid;
      signal (SIGINT, sigChild);
     
      switch (pid = fork()){
        case -1:
          error("fork error");
          break;
        case 0:
          setenv("PARENT",shellPath2,1);
          //printf("%s, %s, %s",readFiles[0],readFiles[1],readFiles[2]);
          ioRedirect(1);

          if (execvp(args[0],args)==-1){
            error("Command not found");
          }
          exit(1);
          break;
      }
      fflush(stdout);
      waitpid(pid, &status, 0);
    }

  }
  
}

void readBatchFile(char filename[fileLength]){
  FILE *fp;
  int lineNo=1;
  fp = fopen(filename,"r");

  if (fp==NULL){
    error("Batch file does not exists");
  }
  while (fgets(inputLine,bufSize,fp)){
    printf("%d. %s",lineNo++,inputLine);
    tokenize();
    runCommand();
    putchar('\n');
  }

  fclose(fp);
  exit(0);
}
