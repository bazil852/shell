//all fucntions used
#include <sys/wait.h>
#include <unistd.h>
#include <string.h>
#include <stdlib.h>
#include <math.h>
#include <string.h>
#include <sys/types.h>
#include <signal.h>


void error(char*);
void updatePath();
void tokenize();
void sigChild();
void ioRedirect(int);
void ioRedirectClose();
void runCommand();
void readBatchFile();